-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 09, 2021 at 07:10 PM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 8.0.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tutionclz`
--

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `id` int(5) NOT NULL,
  `sname` varchar(50) NOT NULL,
  `sage` int(2) NOT NULL,
  `sgrade` int(2) NOT NULL,
  `smobile` int(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`id`, `sname`, `sage`, `sgrade`, `smobile`) VALUES
(1, 'Kasun', 12, 6, 768861369),
(2, 'Amal', 12, 9, 774545110),
(3, 'Lahiru', 21, 11, 774588888),
(4, 'Kasunka', 17, 11, 714545110),
(6, 'Udara', 6, 10, 3243433),
(7, 'SAHAS', 10, 6, 772693702),
(8, 'AMAL', 11, 6, 773147105),
(9, 'ARJITH', 11, 6, 773214105),
(10, 'NUWAN', 14, 9, 778989852),
(11, 'Saman Abey', 15, 10, 451474578),
(12, 'Aseka', 16, 11, 1124545789),
(13, 'Dulika', 17, 9, 12346445),
(14, 'RAKIYA', 18, 11, 11212122),
(16, 'NIRAN', 14, 8, 115686758),
(17, 'JUTE', 10, 6, 457878789),
(18, 'LUCA', 11, 7, 787878759),
(19, 'RUCA', 12, 8, 772686758),
(20, 'YUKA', 13, 9, 568672988),
(21, 'SUCA', 14, 10, 897878758),
(22, 'TUTU', 15, 11, 144542555);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `student`
--
ALTER TABLE `student`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
